<?php

//file that logs the chat
define("TXTFILENAME", "../chat/chat.txt");

//the login data of the database
define("dbHOST", "localhost");
define("dbUSER", "root");
define("dbPASSWORD", "forsakenart");
define("dbNAME", "MOSSchat");


?>
